﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComiqueriaApp;
using ComiqueriaLogic;

namespace ComiqueriaApp
{
    public partial class VentasForm : Form 
    {
        private Producto productoSeleccionado;
        private Comiqueria comiqueria;
        
        public VentasForm(Comiqueria comiqueria,Guid codigoProducto)
        {
            InitializeComponent();
            this.comiqueria = comiqueria; 
            this.productoSeleccionado = comiqueria[codigoProducto];

            lblDescripcion.Text = productoSeleccionado.Descripcion;
            lblPrecioFinal.Text = Convert.ToString(productoSeleccionado.Precio);
        }

        private void numericUpDownCantidad_ValueChanged(object sender, EventArgs e)
        {
            double precioFinal = (double)numericUpDownCantidad.Value * productoSeleccionado.Precio;
            lblPrecioFinal.Text = Convert.ToString(precioFinal);
        }

        private void btnCancelarOnClick(object sender, EventArgs e)
        {
            VentasForm.ActiveForm.Close();
        }

        private void btnVenderOnClick(object sender, EventArgs e)
        {
            int cantidad = (int)numericUpDownCantidad.Value;

            if (cantidad < productoSeleccionado.Stock)
            {
                comiqueria.Vender(productoSeleccionado, cantidad);
                VentasForm.ActiveForm.Close();
            }
            else
            {
                MessageBox.Show("Cantidad de entradas en stock insuficiente.\nDisminuir cantidad de entradas a vender.","Error al comprar",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
    }
}
