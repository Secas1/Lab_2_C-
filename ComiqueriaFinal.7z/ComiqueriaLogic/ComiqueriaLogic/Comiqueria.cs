﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public class Comiqueria
    {
        private List<Producto> productos;
        private List<Venta> ventas;

        public Comiqueria()
        {
            List<Producto> productos = new List<Producto>();
            List<Venta> ventas = new List<Venta>();

            this.productos = productos;
            this.ventas = ventas;
        }

        public Producto this[Guid codigo]
        {
            get
            {
                Producto devProducto = null;

                foreach (Producto producto in productos)
                {
                    if (codigo == (Guid)producto)
                    {
                        devProducto = producto;
                    }
                }

                return devProducto;
            }
        }

        public static bool operator == (Comiqueria comiqueria, Producto producto)
        {
            bool returnVal = false;
            foreach(Producto valProducto in comiqueria.productos)
            {
                if(valProducto.Descripcion == producto.Descripcion)
                {
                    returnVal = true;
                    break;
                }
            }

            return returnVal;
        }

        public static bool operator != (Comiqueria comiqueria,Producto producto)
        {
            return !(comiqueria == producto);
        }

        public static Comiqueria operator + (Comiqueria comiqueria,Producto producto)
        {
            if(comiqueria != producto)
            {
                comiqueria.productos.Add(producto);
            }

            return comiqueria;
        }

        public void Vender(Producto producto,int cantidad)
        {
            Venta nuevaVenta = new Venta(producto, cantidad);
            this.ventas.Add(nuevaVenta);
        }

        public void Vender(Producto producto)
        {
            Vender(producto, 1);
        }

        public string ListarVentas()
        {
            StringBuilder sb = new StringBuilder();
            
            foreach(Venta venta in this.ventas)
            {
                sb.AppendLine(venta.ObtenerDescripcionBreve());
            }

            return sb.ToString();
        }

        public Dictionary<Guid,string> ListarProductos()
        {
            Dictionary<Guid, string> lista = new Dictionary<Guid, string>();

            foreach(Producto producto in this.productos)
            {
                lista.Add((Guid)producto, producto.Descripcion);
            }

            return lista;
        }

    }
}
