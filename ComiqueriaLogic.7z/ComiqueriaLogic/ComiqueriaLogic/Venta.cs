﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    sealed class Venta
    {
        private DateTime fecha;
        private int porcentajeIva;
        private double precioFinal;
        private Producto producto;

        internal DateTime Fecha
        {
            get
            {
                return this.fecha;
            }
        }

        private Venta()
        {
            this.porcentajeIva = 21;
        }

        internal Venta(Producto producto,int cantidad)
        {
            this.porcentajeIva = 21;
            this.producto = producto;
            this.Vender(cantidad);

        }

        private void Vender(int cantidad)
        {
            this.producto.Stock = this.producto.Stock - cantidad;
            this.fecha = DateTime.Now;
            this.precioFinal = CalcularPrecioFinal(this.producto.Precio,cantidad);
        }

        public double CalcularPrecioFinal(double precioUnidad,int cantidad)
        {
            double precioFinal;

            precioFinal = (precioUnidad * cantidad) * ((this.porcentajeIva / 100) + 1);

            return precioFinal;
        }

        public string ObtenerDescripcionBreve()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat(Convert.ToString(Fecha));
            sb.AppendFormat(" -- ");
            sb.AppendFormat(this.producto.Descripcion);
            sb.AppendFormat(" -- ");
            sb.AppendFormat(Convert.ToString(this.precioFinal));

            return sb.ToString();
        }


    }
}
