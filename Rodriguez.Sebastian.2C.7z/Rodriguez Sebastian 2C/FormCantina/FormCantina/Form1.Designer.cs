﻿namespace FormCantina
{
    partial class FrmBasic
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBasic));
            this.btnAgregar = new System.Windows.Forms.Button();
            this.comboBoxTipoBotella = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.txtMarca = new System.Windows.Forms.TextBox();
            this.numUpDownCapacidad = new System.Windows.Forms.NumericUpDown();
            this.numUpDownContenido = new System.Windows.Forms.NumericUpDown();
            this.lblCapacidad = new System.Windows.Forms.Label();
            this.lblContenido = new System.Windows.Forms.Label();
            this.rBtnCerveza = new System.Windows.Forms.RadioButton();
            this.rBtnAgua = new System.Windows.Forms.RadioButton();
            this.barra = new ControlCantina.Barra();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownCapacidad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownContenido)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(293, 365);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(124, 39);
            this.btnAgregar.TabIndex = 0;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            // 
            // comboBoxTipoBotella
            // 
            this.comboBoxTipoBotella.FormattingEnabled = true;
            this.comboBoxTipoBotella.Location = new System.Drawing.Point(296, 326);
            this.comboBoxTipoBotella.Name = "comboBoxTipoBotella";
            this.comboBoxTipoBotella.Size = new System.Drawing.Size(121, 21);
            this.comboBoxTipoBotella.TabIndex = 1;
            this.comboBoxTipoBotella.SelectedIndexChanged += new System.EventHandler(this.comboBoxTipoBotella_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(293, 305);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Botella Tipo";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMarca.Location = new System.Drawing.Point(117, 305);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(50, 18);
            this.lblMarca.TabIndex = 3;
            this.lblMarca.Text = "Marca";
            // 
            // txtMarca
            // 
            this.txtMarca.Location = new System.Drawing.Point(120, 327);
            this.txtMarca.Name = "txtMarca";
            this.txtMarca.Size = new System.Drawing.Size(162, 20);
            this.txtMarca.TabIndex = 4;
            // 
            // numUpDownCapacidad
            // 
            this.numUpDownCapacidad.Location = new System.Drawing.Point(120, 376);
            this.numUpDownCapacidad.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numUpDownCapacidad.Name = "numUpDownCapacidad";
            this.numUpDownCapacidad.Size = new System.Drawing.Size(79, 20);
            this.numUpDownCapacidad.TabIndex = 5;
            // 
            // numUpDownContenido
            // 
            this.numUpDownContenido.Location = new System.Drawing.Point(205, 376);
            this.numUpDownContenido.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numUpDownContenido.Name = "numUpDownContenido";
            this.numUpDownContenido.Size = new System.Drawing.Size(77, 20);
            this.numUpDownContenido.TabIndex = 6;
            // 
            // lblCapacidad
            // 
            this.lblCapacidad.AutoSize = true;
            this.lblCapacidad.Location = new System.Drawing.Point(117, 360);
            this.lblCapacidad.Name = "lblCapacidad";
            this.lblCapacidad.Size = new System.Drawing.Size(58, 13);
            this.lblCapacidad.TabIndex = 7;
            this.lblCapacidad.Text = "Capacidad";
            // 
            // lblContenido
            // 
            this.lblContenido.AutoSize = true;
            this.lblContenido.Location = new System.Drawing.Point(202, 360);
            this.lblContenido.Name = "lblContenido";
            this.lblContenido.Size = new System.Drawing.Size(55, 13);
            this.lblContenido.TabIndex = 8;
            this.lblContenido.Text = "Contenido";
            // 
            // rBtnCerveza
            // 
            this.rBtnCerveza.AutoSize = true;
            this.rBtnCerveza.Checked = true;
            this.rBtnCerveza.Location = new System.Drawing.Point(12, 326);
            this.rBtnCerveza.Name = "rBtnCerveza";
            this.rBtnCerveza.Size = new System.Drawing.Size(64, 17);
            this.rBtnCerveza.TabIndex = 9;
            this.rBtnCerveza.TabStop = true;
            this.rBtnCerveza.Text = "Cerveza";
            this.rBtnCerveza.UseVisualStyleBackColor = true;
            // 
            // rBtnAgua
            // 
            this.rBtnAgua.AutoSize = true;
            this.rBtnAgua.Location = new System.Drawing.Point(12, 349);
            this.rBtnAgua.Name = "rBtnAgua";
            this.rBtnAgua.Size = new System.Drawing.Size(50, 17);
            this.rBtnAgua.TabIndex = 10;
            this.rBtnAgua.TabStop = true;
            this.rBtnAgua.Text = "Agua";
            this.rBtnAgua.UseVisualStyleBackColor = true;
            // 
            // barra
            // 
            this.barra.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("barra.BackgroundImage")));
            this.barra.Location = new System.Drawing.Point(12, 12);
            this.barra.Name = "barra";
            this.barra.Size = new System.Drawing.Size(460, 280);
            this.barra.TabIndex = 11;
            // 
            // FrmBasic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 462);
            this.Controls.Add(this.barra);
            this.Controls.Add(this.rBtnAgua);
            this.Controls.Add(this.rBtnCerveza);
            this.Controls.Add(this.lblContenido);
            this.Controls.Add(this.lblCapacidad);
            this.Controls.Add(this.numUpDownContenido);
            this.Controls.Add(this.numUpDownCapacidad);
            this.Controls.Add(this.txtMarca);
            this.Controls.Add(this.lblMarca);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxTipoBotella);
            this.Controls.Add(this.btnAgregar);
            this.Name = "FrmBasic";
            this.Text = "Sebastian Martin Rodriguez C2";
            this.Load += new System.EventHandler(this.FrmBasic_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownCapacidad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownContenido)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.ComboBox comboBoxTipoBotella;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.TextBox txtMarca;
        private System.Windows.Forms.NumericUpDown numUpDownCapacidad;
        private System.Windows.Forms.NumericUpDown numUpDownContenido;
        private System.Windows.Forms.Label lblCapacidad;
        private System.Windows.Forms.Label lblContenido;
        private System.Windows.Forms.RadioButton rBtnCerveza;
        private System.Windows.Forms.RadioButton rBtnAgua;
        private ControlCantina.Barra barra;
    }
}

