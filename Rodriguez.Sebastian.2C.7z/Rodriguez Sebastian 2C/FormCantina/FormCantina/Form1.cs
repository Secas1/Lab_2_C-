﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ControlCantina;
using Entidades;

namespace FormCantina
{
    public partial class FrmBasic : Form
    {
        public FrmBasic()
        {
            InitializeComponent();
            
        }

        private void comboBoxTipoBotella_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FrmBasic_Load(object sender, EventArgs e)
        {
            numUpDownCapacidad.Value = 1000;
            numUpDownContenido.Value = 1000;
 
            comboBoxTipoBotella.DataSource = Enum.GetValues(typeof(Botella.Tipo));
        }
    }
}
