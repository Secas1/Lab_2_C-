﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Agua : Botella
    {
        const int MEDIDA = 400;

        public Agua(int capacidadML, String marca, int contenidoML)
            : base(marca, capacidadML, contenidoML)
        {
        }

        public override int ServirMedida()
        {
            return ServirMedida(MEDIDA);
        }

        public int ServirMedida(int medida)
        {
            int contenido = base.Contenido;

            if (medida <= contenido)
            {
                contenido = contenido - medida;
            }
            else if (medida > contenido)
            {
                contenido = 0;
            }

            return contenido;
        }
        

        public String GenerarInforme()
        {
            StringBuilder informe = new StringBuilder();
            informe.Append(base.ToString());
            informe.Append("MEDIDA: ").Append(MEDIDA);

            return informe.ToString();
        }
    }
}
