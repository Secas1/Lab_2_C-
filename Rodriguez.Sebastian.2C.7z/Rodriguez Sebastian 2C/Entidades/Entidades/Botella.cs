﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Botella
    {
        private int capacidadML;
        private int contenidoML;
        private String marca;

        protected Botella(String marca, int capacidadML, int contenidoML)
        {
            this.marca = marca;

            if (capacidadML < contenidoML)
            {
                contenidoML = capacidadML;
            }

            this.capacidadML = capacidadML;
            this.contenidoML = contenidoML;
        }

        public int CapacidadLitros
        {
            get
            {
                return (capacidadML / 1000);
            }
        }

        public int Contenido
        {
            get
            {
                return this.contenidoML;
            }
            set
            {
                this.contenidoML = value;
            }
        }

        public float PorcentajeContenido
        {
            get
            {
                float portentaje;
                portentaje = (Contenido * 100) / this.capacidadML;
                return portentaje;
            }
        }

        public abstract int ServirMedida();

        protected String GenerarInforme()
        {
            StringBuilder informe = new StringBuilder();
            informe.Append("Capacidad(ml): ").Append(this.capacidadML);
            informe.Append("Contenido(ml): ").Append(Contenido);
            informe.Append("Marca: ").Append(this.marca);

            return informe.ToString();
        }

        public string ToString()
        {
            return GenerarInforme();
        }

        public enum Tipo
        {
            Plastico,
            Vidrio,
        }


    }
}
