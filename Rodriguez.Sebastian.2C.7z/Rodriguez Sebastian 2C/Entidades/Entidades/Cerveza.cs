﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cerveza : Botella
    {
        const int MEDIDA = 330;

        private Tipo tipo;

        public Cerveza(int capacidadML, string marca, int contenidoML)
            : this(capacidadML, marca, Tipo.Vidrio, contenidoML)
        {
        }

        public Cerveza(int capacidadML, string marca, Tipo tipo, int contenidoML)
            : base(marca, capacidadML, contenidoML)
        {
            this.tipo = tipo;
        }

        public override int ServirMedida()
        {
            return ServirMedida(MEDIDA);
        }

        public int ServirMedida(int medida)
        {
            int contenido = base.Contenido;

            if (medida >= contenido)
            {
                contenido = 0;
            }
            else if (MEDIDA < contenido)
            {
                contenido = contenido - ((medida * 80) / 100);
            }

            return contenido;
        }

        public String GenerarInforme()
        {
            StringBuilder informe = new StringBuilder();

            informe.Append(base.ToString());
            informe.Append("MEDIDA").Append(MEDIDA);

            return informe.ToString();
        }

        public static implicit operator Tipo(Cerveza cerveza)
        {
            return cerveza.tipo;
        }
    }
}
