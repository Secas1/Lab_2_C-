﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Entidades;

namespace Archivos 
{
    public class Texto
    {
        public void Guardar(string archivo, Queue <Patente> datos)
        {
            using (StreamWriter sw = new StreamWriter(archivo))
            {
                foreach (Patente p in datos)
                {
                    sw.WriteLine(p.ToString());
                }
            }
        }

        public void Leer(string archivo, out Queue<Patente> datos)
        {
            using (StreamReader sr = new StreamReader(archivo))
            {
                string line;
                Queue<Patente> queDatos = new Queue<Patente>();
                while ((line = sr.ReadLine()) != null)
                {
                    Patente patente = new Patente();
                    patente.CodigoPatente = line;

                    queDatos.Enqueue(patente);
                }

                datos = queDatos;
            }   
        }
    }
}
