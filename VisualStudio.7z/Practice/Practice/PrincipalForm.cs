﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Practice_Methods;

namespace Practice
{
    public partial class frmRead : Form
    {
        public frmRead()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Person person = new Person(txtBoxName.Text, txtBoxSurname.Text, dtPickerDateOfBirth.Value, Convert.ToInt32(txtBoxDni.Text));

            DataManagement.SavePerson(person,(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Data.txt"));
        }

        private void btnLoadData_Click(object sender, EventArgs e)
        {
            Person person = DataManagement.ReadPerson(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Data.txt");

            txtBoxName.Text = person.name;
            txtBoxSurname.Text = person.surname;
            txtBoxDni.Text = Convert.ToString(person.dni);
            dtPickerDateOfBirth.Value = person.dateOfBirth;
        }
    }
}
