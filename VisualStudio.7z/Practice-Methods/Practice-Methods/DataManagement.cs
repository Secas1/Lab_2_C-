﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Practice_Methods
{
    public class DataManagement
    {
        public static void SavePerson(Person person,String filePath)
        {
            if (person == null) { return; }

            try
            {
                XmlDocument xmlDocument = new XmlDocument();
                XmlSerializer serializer = new XmlSerializer(person.GetType());

                using (MemoryStream stream = new MemoryStream())
                {
                    serializer.Serialize(stream,person);
                    stream.Position = 0;
                    xmlDocument.Load(stream);
                    xmlDocument.Save(filePath);
                }

            }
            catch (FileNotFoundException e)
            {

                throw;
            }
            catch(Exception e)
            {
                throw;
            }
        }

        public static Person ReadPerson(String filePath)
        {
            Person person = new Person();

            if (!System.IO.File.Exists(filePath)) { return person; }

            try
            {
                String attributeXml = String.Empty;
                XmlDocument xmlDocument = new XmlDocument();

                xmlDocument.Load(filePath);
                String xmlString = xmlDocument.OuterXml;

                using (StringReader read = new StringReader(xmlString))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(Person));

                    using (XmlReader reader = new XmlTextReader(read))
                    {
                        person = (Person)serializer.Deserialize(reader);
                    }
                }

            }
            catch (FileNotFoundException e)
            {
                throw;
            }

            return person;
        }
    }
}
