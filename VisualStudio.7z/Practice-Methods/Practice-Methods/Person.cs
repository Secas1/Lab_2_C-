﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice_Methods
{   
    public class Person
    {
        public String name;
        public String surname;
        public DateTime dateOfBirth;
        public int age;
        public int dni;

        public Person() { }

        public Person(String name, String surname, DateTime dateOfBirth,int dni)
        {
            this.name = name;
            this.surname = surname;
            this.dateOfBirth = dateOfBirth;
            this.dni = dni;
            this.age = GetAge;
        }

        public Person(Person person)
            :this(person.name,person.surname,person.dateOfBirth,person.dni)
        {
        }

        private int GetAge
        {
            get
            {
                return DateTime.Now.Year - dateOfBirth.Year;
            }
        }
    }
}
