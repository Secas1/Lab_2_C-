﻿using System;
using Biblioteca;

namespace Mostrar
{
    class Program
    {
        static void Main(string[] args)
        {
            DAO.InsertarCliente("Sebastian","Rodriguez","88888888");

            Console.ReadKey();
        }
    }
}
