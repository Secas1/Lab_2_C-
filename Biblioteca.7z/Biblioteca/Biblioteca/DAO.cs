﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public static class DAO
    {
        private static SqlConnection connection;
        private static SqlCommand command;

        static DAO()
        {
            string connectionString = @"Data Source= ./; Initial Catalog = BDVet; Integrated Security = true";
            connection = new SqlConnection(connectionString);
            command = new SqlCommand();
            command.Connection = connection;
            command.CommandType = System.Data.CommandType.Text;
        }

        public static void InsertarCliente(String nombre, String apellido, String dni)
        {
            try
            {
                connection.Open();
                string comando = String.Format("INSERT INTO Clientes (nombre,apellido,dni) VALUES ('{0}','{1}','{2}')", nombre,apellido,dni);
                command.CommandText = comando;
                command.ExecuteNonQuery();
            }
            finally
            {
                if (connection != null && connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();

                }
            }
        }
    }
}
