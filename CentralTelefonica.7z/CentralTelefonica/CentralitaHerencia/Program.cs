﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    class Program
    {
        static void Main(string[] args)
        {
            Llamada test = new Llamada(10, "123", "456");
            Console.WriteLine(test.Mostrar());
            Local testLocal = new Local(test, 20);
            Console.WriteLine(testLocal.Mostrar());
            Provincial testProvincial = new Provincial(Provincial.Franja.Franja_2,test);
            Console.WriteLine(testProvincial.Mostrar());
            Console.ReadKey();
        }
    }
}
