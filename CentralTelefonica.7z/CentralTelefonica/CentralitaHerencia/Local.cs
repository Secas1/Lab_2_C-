﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
     public class Local : Llamada
    {
        private float costo;

        private float CalcularCosto()
        {
            return this.costo * base.duracion;
        }

        public float CostoLlamada
        {
            get
            {
                return CalcularCosto();
            }
        }

        public Local(){}

        public Local(Llamada llamada,float costo)
            :base(llamada.Duracion,llamada.NroDestino,llamada.NroOrigen)
        {
            this.costo = costo;
        }

        public Local (string origen,float duracion,string destino,float costo)
            :this(new Llamada(duracion,destino,origen),costo)
        {
        }

        public string  Mostrar()
        {
            StringBuilder sb = new StringBuilder(base.Mostrar());
            sb.AppendFormat("\tCosto Local");
            sb.AppendFormat(":{0}", this.CostoLlamada);
            return sb.ToString();
        }
    }
}
