﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Provincial : Llamada
    {
        Franja franjaHoraria;

        public enum Franja
        {
            Franja_1,
            Franja_2,
            Franja_3
        }

        public Provincial() { }

        public Provincial(Franja miFranja,Llamada llamada)
        {
            this.franjaHoraria = miFranja;
            base.duracion = llamada.Duracion;
            base.nroDestino = llamada.NroDestino;
            base.nroOrigen = llamada.NroOrigen;
        }

        public Provincial(string origen,Franja miFranja,float duracion,string destino)
        {
            this.franjaHoraria = miFranja;
            base.duracion = duracion;
            base.nroDestino = destino;
            base.nroOrigen = origen;
        }

        private float CalcularCosto
        {
            get
            {
                float total = 0;

                switch (this.franjaHoraria)
                {
                    case Franja.Franja_1:
                        total = base.Duracion * 0.99f;
                        break;

                    case Franja.Franja_2:
                        total = base.Duracion * 1.25f;
                        break;

                    case Franja.Franja_3:
                        total = base.Duracion * 0.66f;
                        break;
                }

                return total;
            }
        }


        public float CostoLlamada
        {
            get
            {
                return CalcularCosto;
            }
        }
        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder(base.Mostrar());
            sb.AppendFormat("\tCosto Provincial");
            sb.AppendFormat(": {0}", CalcularCosto);

            return sb.ToString();
        }
    }
}
