﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CentralitaHerencia.Llamada;

namespace CentralitaHerencia
{
    class Centralita
    {
        private List<Llamada> listaDeLlamadas;
        protected string razonSocial;

        private float CalcularGanancia(Llamada.TipoLlamada tipo)
        {
            float sumador=0;
            
            foreach (Llamada llamada in listaDeLlamadas)
            {
                
                switch (tipo)
                {
                    case Llamada.TipoLlamada.Local:
                        if(llamada.GetType() == typeof(Local))
                        {
                            sumador += ((Local)llamada).CostoLlamada;
                        }
                    break;

                    case Llamada.TipoLlamada.Provincial:
                        if (llamada.GetType() == typeof(Provincial))
                        {
                            sumador += ((Provincial)llamada).CostoLlamada;
                        }
                    break;

                    case Llamada.TipoLlamada.Todas:
                        sumador = CalcularGanancia(TipoLlamada.Local) + CalcularGanancia(TipoLlamada.Provincial);
                    break;
                }

            }

            return sumador;
        }

        public float GananciaPorLocal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Local);
            }
        }

        public float GananciaPorProvincia
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Provincial);
            }
        }

        public float GananciaPorTotal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Todas);
            }
        }

        public List<Llamada> Llamadas
        {
            get
            {
                return listaDeLlamadas;
            }
        }

        public Centralita()
        {
            List<Llamada> listaLlamadasNueva = new List<Llamada>();
            listaDeLlamadas = listaLlamadasNueva;
        }

        public Centralita(string nombreEmpresa)
        {
            List<Llamada> listaLlamadasNueva = new List<Llamada>();
            listaDeLlamadas = listaLlamadasNueva;
            this.razonSocial = nombreEmpresa;
        }

        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Razon Social");
            sb.AppendFormat(": {0}", this.razonSocial);
            sb.AppendFormat("\tGanancia Total");
            sb.AppendFormat(": {0}",GananciaPorTotal);
            sb.AppendFormat("\tGanancia Local");
            sb.AppendFormat(": {0}", GananciaPorTotal);
            sb.AppendFormat("\tGanancia Provincial");
            sb.AppendFormat(": {0}", GananciaPorProvincia);

            return sb.ToString();
        }
    }
}
