﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_05
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            int sum1=0, sum2=0;

            Console.WriteLine("Numero: ");
            num = Convert.ToInt32(Console.ReadLine());

            for(int i = 1; i <= num; i++)
            {
                sum1 = 0;
                for(int j = 0; j < i; j++)
                {
                    sum1 = sum1 + j;
                }
                //Console.WriteLine(sum1);

                sum2 = 0;
                for(int z=i+1;z<=num;z++)
                {
                    sum2 = sum2 + z;
                }
                //Console.WriteLine(sum2);

                if (sum1 == sum2)
                {
                    Console.WriteLine("Numero Central: " + i);
                }
            }

            
            Console.ReadKey();
        }
    }
}
