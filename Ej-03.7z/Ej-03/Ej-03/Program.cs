﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_03
{
    class Program
    {
        static void Main(string[] args)
        {
            int Num,Count=0;
            int Ok=0;
            int Primo=0;

            Console.WriteLine("Number: ");
            Num = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= Num; i++)
            {
                Console.WriteLine(i);

                Ok = 0;
                for (int j = 1; j <= i; i++)
                {

                    if ((i % j) == 0)
                    {
                        Ok++;

                        if (Ok == 2)
                        {
                            Primo = 1;
                            break;
                        }
                    }
                }

                if (Primo==1)
                {
                    Count++;
                }

            }

            Console.WriteLine("Num.Primos: " + Count); 

            Console.ReadKey();
        }
    }
}
