﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_04
{
    class Program
    {
        static void Main(string[] args)
        {
            int Perfect = 0;
            int num = 0;
            int Cant=0;

            while (Perfect < 4)
            {
                num++;
                Cant = 0;
                for(int i = 1; i <= num; i++)
                {
                    if ((num % i) == 0)
                    {
                        Cant = Cant + i;
                    }
                }
                Cant = Cant - num;

                if (Cant == num)
                {
                    Console.WriteLine(Cant+"="+num); 
                    Perfect++;
                }
            }

            Console.ReadKey();
        }
    }
}
