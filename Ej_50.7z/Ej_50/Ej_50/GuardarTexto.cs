﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_50
{
    public class GuardarTexto <T,V> : IGuardar<T,V>
    {
        public bool Guardar(T obj)
        {
            return true;
        }

        public V Leer()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Texto leido");
            return (V)Convert.ChangeType(sb, typeof(V));
        }
    }
}
