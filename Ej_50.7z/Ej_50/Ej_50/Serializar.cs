﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_50
{
    class Serializar <S,V> : IGuardar<S,V>
    {
        public bool Guardar(S obj)
        {
            return true;
        }

        public V Leer()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Objeto leido");
            return (V)Convert.ChangeType(sb, typeof(V));
        }
    }
}
