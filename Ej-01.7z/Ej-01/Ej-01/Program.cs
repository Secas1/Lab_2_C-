﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_01
{
    class Program
    {
        static void Main(string[] args)
        {
            int number, max, min, prom,z;

            Console.WriteLine("Number 1: ");
            number = Convert.ToInt32(Console.ReadLine());
            min = number;
            max = number;
            z = number;

            for (int i=1;i<5; i++)
            {
                Console.WriteLine("Number "+(i+1)+": ");
                number = Convert.ToInt32(Console.ReadLine());
                //Console.WriteLine("N: " + number);

                if (number > max)
                {
                    max = number;
                }
                if (number < min)
                {
                    min=number;
                }
                z = z + number;
            }

            prom = z/5;

            Console.WriteLine("Max: " + max);
            Console.WriteLine("Min: " + min);
            Console.WriteLine("Prom: " + prom);

            Console.ReadKey();
        }

    }
}
