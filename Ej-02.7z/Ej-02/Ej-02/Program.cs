﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_02
{
    class Program
    {
        static void Main(string[] args)
        {
            int Number;
            Console.WriteLine("Number: ");
            Number = Convert.ToInt32(Console.ReadLine());
            
            while (Number < 0)
            {
                Console.WriteLine("ERROR. ¡Reingresar Numero!");
                Number = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine(Number + "^2: " + (Math.Pow(Number,2)));
            Console.WriteLine(Number + "^3: " + (Math.Pow(Number, 3)));

            Console.ReadKey();
        }
    }
}
