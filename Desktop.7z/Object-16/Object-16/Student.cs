﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Object_16
{
    public class Student
    {
        private string surname;
        private int file;
        private string name;
        private int note1,note2,finalNote;

        public int Note1
        {
            get { return note1; }
            set { note1 = value; }
        }

        public int Note2
        {
            get { return note2; }
            set { note2 = value; }
        }

        public  int FinalNote
        {
            get { return finalNote; }
            set { finalNote = value; }
        }


        public void Study(byte note1,byte note2)
        {
            Note1 = note1;
            Note2 = note2;
        }

        public void CalculateFinal()
        {
            if (Note1 >= 4 && Note2 <= 4)
            {
                Random random = new Random();

                FinalNote = random.Next(0,100);
            }
            else
            {
                FinalNote = -1;
            }
        }

        public string showStudent()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("\nNote 1: ");
            sb.AppendFormat("{0}",Note1);
            sb.AppendFormat("\tNote 2: ");
            sb.AppendFormat("{0}",Note2);
            sb.AppendFormat("\tFinal Note: ");
            sb.AppendFormat("{0}",FinalNote);

            return sb.ToString();
        }
    }
}
