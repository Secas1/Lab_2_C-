﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Object_16
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student1 = new Student();
            Student student2 = new Student();
            Student student3 = new Student();

            student1.Study(1, 6);
            student2.Study(5, 9);
            student3.Study(9, 8);

            student1.CalculateFinal();
            student2.CalculateFinal();
            student3.CalculateFinal();

            Console.WriteLine(student1.showStudent());
            Console.WriteLine(student2.showStudent());
            Console.WriteLine(student3.showStudent());

            Console.ReadKey();
        }
    }
}
