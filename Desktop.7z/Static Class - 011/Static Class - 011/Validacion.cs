﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static_Class_011
{
    public class Validacion
    {
        public static bool validar(int valor,int min,int max)
        {
            if (valor >= min && valor <= max)
            {
                return true;
            }
            return false;
        }

        public static int min(int number, int min)
        {
            if (number < min)
            {
                return number;
            }
            else return min;
        }

        public static int max(int number, int max)
        {
            if(number > max)
            {
                return number;
            }
            else return max;
        }

        public static string mostar(int min,int max,double average)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Minimo: ");
            sb.AppendFormat("{0}",min);
            sb.AppendFormat("\nMaximo: ");
            sb.AppendFormat("{0}",max);
            sb.AppendFormat("\nPromedio: ");
            sb.AppendFormat("{0}",average);

            return sb.ToString();
        }
    }
}
