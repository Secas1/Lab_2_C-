﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static_Class_011
{
    class Program
    {
        static void Main(string[] args)
        {
            double average=0,accumulator=0;
            int number=0,min=100,max=0;

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Number: ");
                number = Convert.ToInt32(Console.ReadLine());

                min = Validacion.min(number, min);
                max = Validacion.max(number, max);
                accumulator = number;

                while (!Validacion.validar(number, 0, 100))
                {
                    Console.WriteLine("Re-enter number: ");
                    number = Convert.ToInt32(Console.ReadLine());
                }

                
                accumulator = accumulator + number;
            }

            average = accumulator / 10;
            Console.WriteLine(Validacion.mostar(min, max, average));

            Console.ReadKey();
        }
    }
}
