﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticClass_012
{
    class Program
    {
        static void Main(string[] args)
        {
            char reply;
            int number=0,sum=0;

            do
            {
                Console.WriteLine("Numero: ");
                number = Convert.ToInt32(Console.ReadLine());
                sum = sum + number;

                Console.WriteLine("Seguir? S/N");
                reply = Convert.ToChar(Console.ReadLine());

            } while (ValidarRespuesta.validarS_N(reply));

            Console.WriteLine("Total: {0}", sum);
            Console.ReadKey();
        }
    }
}
